import React from "react";
import "./common.css"

const Footer = () => (
  <div className="footer">
    <span>&#169;</span><bold>TweetApp By Cognizant,2022.All rights Reserved.</bold>
  </div>
);

export default Footer;